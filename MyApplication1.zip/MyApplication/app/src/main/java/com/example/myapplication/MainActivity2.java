package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        TextView question= findViewById(R.id.question);
        TextView question2= findViewById(R.id.question2);

        Bundle arguments = getIntent().getExtras();

        if(arguments!=null){
            String result1 = arguments.get("result1").toString();
            question.setText( result1 );
        }
        if(arguments!=null){
            String result2 = arguments.get("result2").toString();
            question2.setText( result2 );
        }

    }
}