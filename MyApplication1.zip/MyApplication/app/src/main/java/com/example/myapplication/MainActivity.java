package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Click(View view) {
        EditText result1 = findViewById(R.id.resultnumber1);
        String Result1 = result1.getText().toString();
        EditText result2 = findViewById(R.id.resultNumber2);
        String Result2 = result2.getText().toString();
        Intent intent = new Intent(this, MainActivity2.class);

        intent.putExtra("result1", Result1);
        intent.putExtra("result2", Result2);
        startActivity(intent);
    }
    public void onClick(View view) {
        Snackbar.make(view, "Saved", Snackbar.LENGTH_LONG)
                .show();

    }
}